import {parsedExpressions} from "./core/helpers";
import balanceChecker from './core/balanceChecker'
import expressionParser from './core/expressionParser'
import PriorityTreeBuilder from './core/priorityTreeBuilder'
import executor from './core/executor'

export default function calculate (expression: string):number|string {
  let result:number|string;

  if (balanceChecker(expression)) {
    let parsedExpression:parsedExpressions = expressionParser(expression);
    let prioritizedTree = new PriorityTreeBuilder(parsedExpression);
    result = executor(prioritizedTree.build());
  } else {
    result = "The expression has unbalanced parentheses.";
  }

  return result;
}
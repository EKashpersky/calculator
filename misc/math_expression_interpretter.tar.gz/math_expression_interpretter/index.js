"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var balanceChecker_1 = require("./core/balanceChecker");
var expressionParser_1 = require("./core/expressionParser");
var priorityTreeBuilder_1 = require("./core/priorityTreeBuilder");
var executor_1 = require("./core/executor");
function calculate(expression) {
    var result;
    if (balanceChecker_1.default(expression)) {
        var parsedExpression = expressionParser_1.default(expression);
        var prioritizedTree = new priorityTreeBuilder_1.default(parsedExpression);
        result = executor_1.default(prioritizedTree.build());
    }
    else {
        result = "The expression has unbalanced parentheses.";
    }
    return result;
}
exports.default = calculate;
//# sourceMappingURL=index.js.map
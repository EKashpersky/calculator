"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var helpers_1 = require("./helpers");
var PriorityTreeBuilder = (function () {
    function PriorityTreeBuilder(parsedExpression) {
        this._parsedExpression = parsedExpression;
        this._position = 0;
    }
    /*===========================================================================
     * Helpers | level 1
     *===========================================================================
    */
    PriorityTreeBuilder.prototype._current = function () {
        return this._parsedExpression[this._position];
    };
    PriorityTreeBuilder.prototype._take = function () {
        return this._parsedExpression[this._position++];
    };
    /*===========================================================================
     * Helpers | level 2
     *===========================================================================
    */
    PriorityTreeBuilder.prototype._isNumber = function () {
        return !isNaN(+this._current());
    };
    PriorityTreeBuilder.prototype._isComplexOperator = function () {
        var current = this._current();
        return helpers_1.OPERATOR_COMPLEX.indexOf(current) != -1;
    };
    PriorityTreeBuilder.prototype._isSimpleOperator = function () {
        var current = this._current();
        return helpers_1.OPERATOR_SIMPLE.indexOf(current) != -1;
    };
    PriorityTreeBuilder.prototype._isParentheses = function () {
        return this._current() == helpers_1.PARENTHESES.LEFT;
    };
    /*===========================================================================
     * Main methods.
     *===========================================================================
    */
    /**
     * Builds number or operator from current token.
    **/
    PriorityTreeBuilder.prototype._buildFromToken = function () {
        if (this._isNumber()) {
            return {
                type: "n",
                value: this._take(),
            };
        }
        else if (this._isParentheses()) {
            this._position++; // increment, because current is (
            var tree = this.build();
            this._position++; // increment, because current is )
            return tree;
        }
        else {
            throw new SyntaxError("Unexpected token " + this._current() + ", position is " + this._position + ".");
        }
    };
    /**
     * Builds tree of complex operators(/*^).
    **/
    PriorityTreeBuilder.prototype._buildComplexOperator = function () {
        var node = this._buildFromToken();
        while (this._isComplexOperator()) {
            var operator = this._take();
            node = { left: node, right: this._buildFromToken(), type: operator };
        }
        return node;
    };
    /**
     * Builds tree of simple operators(+-).
    **/
    PriorityTreeBuilder.prototype._buildSimpleOperator = function () {
        var node = this._buildComplexOperator();
        while (this._isSimpleOperator()) {
            var operator = this._take();
            node = { left: node, right: this._buildComplexOperator(), type: operator };
        }
        return node;
    };
    PriorityTreeBuilder.prototype.build = function () {
        return this._buildSimpleOperator();
    };
    return PriorityTreeBuilder;
}());
exports.default = PriorityTreeBuilder;
//# sourceMappingURL=priorityTreeBuilder.js.map
import {OPERATORS, PARENTHESES} from './helpers'

const special = [...OPERATORS, PARENTHESES.LEFT, PARENTHESES.RIGHT];

/**
 * Makes tokens array from the expression.
**/
export default function expressionParser (expression:string):number[]|string[] {
  let parsedExpression = [];

  for (let x:number = 0, y:number = expression.length; x < y; x++) {
    let char:string = expression[x];

    /**
     * A digit.
    **/
    if (/\d+/.test(char)) {
      /**
       * Tries to get whole number from current position.
       * TODO(ek): create a handler for very long double numbers.
      **/
      let number:number = parseFloat(expression.substring(x));

      parsedExpression.push(number);

      /**
       * Updates current position for length of number.
      **/
      x += ("" + number).length - 1;
    /**
     * Just adds special character to the `parsedExpression` array.
    **/
    } else if (special.indexOf(char) != -1) {
      parsedExpression.push(char);
    } else {
      throw new SyntaxError(`Unexpected ${char} character.`);
    }
  }

  return parsedExpression;
};
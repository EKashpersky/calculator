"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var helpers_1 = require("./helpers");
function precision(x, y) {
    var __precision = 0, __split = ("" + x).split(".")[1];
    if (__split) {
        __precision = __split.length;
    }
    __split = ("" + y).split(".")[1];
    if (__split && __split.length > __precision) {
        __precision = __split.length;
    }
    return __precision;
}
/**
 * Coverts 1.03 to 103.00
**/
function precise(number, precision) {
    return +(number * +("1e" + precision)).toFixed(precision);
}
/**
 * Performs percent operation over two float numbers without float problem.
**/
function percent(x, y) {
    var __precision = precision(x, y);
    if (__precision > 0) {
        x = precise(x, __precision);
        y = precise(y, __precision);
    }
    x -= Math.floor(x / y) * y;
    x /= +("1e" + __precision);
    return +(x.toFixed(__precision));
}
/**
 * Performs minus operation over two float numbers without float problem.
**/
function plus(x, y) {
    var __precision = precision(x, y);
    if (__precision > 0) {
        x = precise(x, __precision);
        y = precise(y, __precision);
    }
    var result = x + y;
    result /= +("1e" + __precision);
    return +(result.toFixed(__precision));
}
/**
 * Performs minus operation over two float numbers without float problem.
**/
function minus(x, y) {
    var __precision = precision(x, y);
    if (__precision > 0) {
        x = precise(x, __precision);
        y = precise(y, __precision);
    }
    var result = x - y;
    result /= +("1e" + __precision);
    return +(result.toFixed(__precision));
}
/**
 * Goes through the whole tree, gets the numbers inside and calculates 'em.
**/
function executor(prioritizedTree) {
    var left, right;
    if (prioritizedTree.left != null) {
        if (prioritizedTree.left.type != "n") {
            left = executor(prioritizedTree.left);
        }
        else {
            left = prioritizedTree.left.value;
        }
    }
    if (prioritizedTree.right != null) {
        if (prioritizedTree.right.type != "n") {
            right = executor(prioritizedTree.right);
        }
        else {
            right = prioritizedTree.right.value;
        }
    }
    if (left == null || right == null) {
        return left || right;
    }
    switch (prioritizedTree.type) {
        case helpers_1.OPERATOR.PLUS: return plus(left, right);
        case helpers_1.OPERATOR.MINUS: return minus(left, right);
        case helpers_1.OPERATOR.MULTIPLY: return left * right;
        case helpers_1.OPERATOR.DIVIDE: return left / right;
        case helpers_1.OPERATOR.POWER: return Math.pow(left, right);
        case helpers_1.OPERATOR.PERCENT: return percent(left, right);
    }
}
exports.default = executor;
//# sourceMappingURL=executor.js.map
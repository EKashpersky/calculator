import {PARENTHESES} from './helpers';

/**
 * Checks the balance of parenthesis in the expression string.
**/
export default function balanceChecker (expression:string):boolean {
  /**
   * Kinda fast checking.
  **/
  if (expression.indexOf(PARENTHESES.LEFT) == -1
    && expression.indexOf(PARENTHESES.RIGHT) == -1
  ) {
    return true;
  }

  let balance = 0;

  for (let char of expression) {
    char == PARENTHESES.LEFT
      ? balance++
      : char == PARENTHESES.RIGHT
        ? balance--
        : null;
  }

  return balance == 0;
};
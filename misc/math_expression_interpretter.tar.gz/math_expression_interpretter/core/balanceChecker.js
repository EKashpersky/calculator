"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var helpers_1 = require("./helpers");
/**
 * Checks the balance of parenthesis in the expression string.
**/
function balanceChecker(expression) {
    /**
     * Kinda fast checking.
    **/
    if (expression.indexOf(helpers_1.PARENTHESES.LEFT) == -1
        && expression.indexOf(helpers_1.PARENTHESES.RIGHT) == -1) {
        return true;
    }
    var balance = 0;
    for (var _i = 0, expression_1 = expression; _i < expression_1.length; _i++) {
        var char = expression_1[_i];
        char == helpers_1.PARENTHESES.LEFT
            ? balance++
            : char == helpers_1.PARENTHESES.RIGHT
                ? balance--
                : null;
    }
    return balance == 0;
}
exports.default = balanceChecker;
;
//# sourceMappingURL=balanceChecker.js.map
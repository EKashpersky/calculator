"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var helpers_1 = require("./helpers");
var special = helpers_1.OPERATORS.concat([helpers_1.PARENTHESES.LEFT, helpers_1.PARENTHESES.RIGHT]);
/**
 * Makes tokens array from the expression.
**/
function expressionParser(expression) {
    var parsedExpression = [];
    for (var x = 0, y = expression.length; x < y; x++) {
        var char = expression[x];
        /**
         * A digit.
        **/
        if (/\d+/.test(char)) {
            /**
             * Tries to get whole number from current position.
             * TODO(ek): create a handler for very long double numbers.
            **/
            var number = parseFloat(expression.substring(x));
            parsedExpression.push(number);
            /**
             * Updates current position for length of number.
            **/
            x += ("" + number).length - 1;
            /**
             * Just adds special character to the `parsedExpression` array.
            **/
        }
        else if (special.indexOf(char) != -1) {
            parsedExpression.push(char);
        }
        else {
            throw new SyntaxError("Unexpected " + char + " character.");
        }
    }
    return parsedExpression;
}
exports.default = expressionParser;
;
//# sourceMappingURL=expressionParser.js.map
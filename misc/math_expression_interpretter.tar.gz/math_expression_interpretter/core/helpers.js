"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var OPERATOR_MULTIPLY = "*";
var OPERATOR_PLUS = "+";
var OPERATOR_MINUS = "-";
var OPERATOR_DIVIDE = "/";
var OPERATOR_POWER = "^";
var OPERATOR_PERCENT = "%";
exports.OPERATOR_COMPLEX = [
    OPERATOR_MULTIPLY,
    OPERATOR_DIVIDE,
    OPERATOR_POWER,
    OPERATOR_PERCENT,
];
exports.OPERATOR_SIMPLE = [
    OPERATOR_MINUS,
    OPERATOR_PLUS,
];
exports.PARENTHESES = {
    LEFT: "(",
    RIGHT: ")",
};
exports.OPERATOR = {
    MULTIPLY: OPERATOR_MULTIPLY,
    PLUS: OPERATOR_PLUS,
    MINUS: OPERATOR_MINUS,
    DIVIDE: OPERATOR_DIVIDE,
    POWER: OPERATOR_POWER,
    PERCENT: OPERATOR_PERCENT,
};
exports.OPERATORS = exports.OPERATOR_SIMPLE.concat(exports.OPERATOR_COMPLEX);
//# sourceMappingURL=helpers.js.map
interface PARENTHESES {
  LEFT:  string,
  RIGHT: string,
}

interface OPERATOR {
  MULTIPLY: string,
  PLUS:    string,
  MINUS:   string,
  DIVIDE:  string,
  POWER:   string,
  PERCENT: string,
}

const OPERATOR_MULTIPLY:string = "*";
const OPERATOR_PLUS:string     = "+";
const OPERATOR_MINUS:string    = "-";
const OPERATOR_DIVIDE:string   = "/";
const OPERATOR_POWER:string    = "^";
const OPERATOR_PERCENT:string  = "%";

export const OPERATOR_COMPLEX = [
  OPERATOR_MULTIPLY,
  OPERATOR_DIVIDE,
  OPERATOR_POWER,
  OPERATOR_PERCENT,
];

export const OPERATOR_SIMPLE = [
  OPERATOR_MINUS,
  OPERATOR_PLUS,
];

export const PARENTHESES:PARENTHESES = {
  LEFT:  "(",
  RIGHT: ")",
};

export const OPERATOR:OPERATOR = {
  MULTIPLY : OPERATOR_MULTIPLY,
  PLUS     : OPERATOR_PLUS,
  MINUS    : OPERATOR_MINUS,
  DIVIDE   : OPERATOR_DIVIDE,
  POWER    : OPERATOR_POWER,
  PERCENT  : OPERATOR_PERCENT,
};

export const OPERATORS:string[] = [...OPERATOR_SIMPLE, ...OPERATOR_COMPLEX];

export interface iTree {
  left?:  iTree,
  right?: iTree,
  type: number|string,
  value?: number
}

export type parsedExpressions = number[]|string[];
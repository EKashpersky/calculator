import {
  iTree,
  OPERATOR,
  PARENTHESES,
  parsedExpressions,
  OPERATOR_SIMPLE,
  OPERATOR_COMPLEX
} from './helpers'

export default class PriorityTreeBuilder {
  _parsedExpression:parsedExpressions;
  _position:number;

  public constructor (parsedExpression) {
    this._parsedExpression = parsedExpression;
    this._position = 0;
  }

  /*===========================================================================
   * Helpers | level 1
   *===========================================================================
  */

  private _current () {
    return this._parsedExpression[this._position];
  }

  private _take () {
    return this._parsedExpression[this._position++];
  }

  /*===========================================================================
   * Helpers | level 2
   *===========================================================================
  */

  private _isNumber ():boolean {
    return !isNaN(+this._current());
  }

  private _isComplexOperator ():boolean {
    let current = this._current();
    return OPERATOR_COMPLEX.indexOf(<string>current) != -1;
  }

  private _isSimpleOperator ():boolean {
    let current = this._current();
    return OPERATOR_SIMPLE.indexOf(<string>current) != -1;
  }

  private _isParentheses ():boolean {
    return this._current() == PARENTHESES.LEFT;
  }

  /*===========================================================================
   * Main methods.
   *===========================================================================
  */

  /**
   * Builds number or operator from current token.
  **/
  private _buildFromToken ():iTree {
    if (this._isNumber()) {
      return <iTree>{
        type: "n",
        value: this._take(),
      };
    } else if (this._isParentheses()) {
      this._position++; // increment, because current is (
      let tree:iTree = this.build();
      this._position++; // increment, because current is )
      return tree;
    } else {
      throw new SyntaxError(
        `Unexpected token ${this._current()}, position is ${this._position}.`
      );
    }
  }

  /**
   * Builds tree of complex operators(/*^).
  **/
  private _buildComplexOperator ():iTree {
    let node:iTree = this._buildFromToken();

    while (this._isComplexOperator()) {
      let operator:number|string = this._take();
      node = {left: node, right: this._buildFromToken(), type: operator};
    }

    return node;
  }

  /**
   * Builds tree of simple operators(+-).
  **/
  private _buildSimpleOperator () {
    let node = this._buildComplexOperator();

    while (this._isSimpleOperator()) {
      let operator = this._take();
      node = {left: node, right: this._buildComplexOperator(), type: operator};
    }

    return node;
  }

  public build ():iTree {
    return this._buildSimpleOperator();
  }
}